<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
	<head>

		<meta charset="utf-8">
		<title>Unite Gallery - Tiles - Columns - Default</title>		
		<meta name="keywords" content="Unite Gallery" />
		<meta name="description" content="Unite Gallery - touch enabled reponsive image and video web gallery width zoom effect">
		<meta name="author" content="Valiano">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css">
		<link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.css">
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-elements.css">
		<link rel="stylesheet" href="css/theme-animate.css">
		<link rel="stylesheet" href="css/theme-responsive.css" />
		<link rel="stylesheet" href="css/skins/default.css">
		<link rel="stylesheet" href="css/custom.css">
		<link rel="stylesheet" href="css/prism.css">

		<!-- Head Libs -->
		<script src="vendor/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="vendor/respond.js"></script>
		<![endif]-->

		<!-- 
		<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script>	
		 -->
		
		<script type='text/javascript' src='unitegallery/js/jquery-11.0.min.js'></script>
		<script src="vendor/bootstrap/js/bootstrap.js"></script>
		<script src="js/prism.js"></script>
		<script src="js/theme.plugins.js"></script>
		<script src="js/theme.js"></script>
		<script src="js/custom.js"></script>
		
				
		<!-- Include Unite Gallery -->
		<script type='text/javascript' src='unitegallery/js/unitegallery.min.js'></script>		
		<link rel='stylesheet' href='unitegallery/css/unite-gallery.css' type='text/css' />	
				
				<script type='text/javascript' src='unitegallery/themes/tiles/ug-theme-tiles.js'></script>
		
	</head>
	<body class="language-javascript">

		<div class="body">
			<header id="header">
				<div class="container">
					<h1 class="logo">
						<a href="index.php">
							<img alt="Unite Gallery" width="143" height="69" data-sticky-width="129" data-sticky-height="62" src="img/logo_top.png">
						</a>
					</h1>
					
					
					<div id="nav-links">
						
						<span class='nav-links-before'>
							Also available for:
						</span>
						
						<nav>
						<ul id="nav-links-menu" class="nav nav-pills nav-top nav-main">
							<li class='dropdown'>
								<a href="http://wp.unitegallery.net/" class="dropdown-toggle" target="_blank" >WordPress</a>
 								<ul class="dropdown-menu"> 				
	 								<li><a href="http://wp.unitegallery.net/" target="_blank">Preview Demo</a></li>
									<li><a href="http://codecanyon.net/item/unite-gallery-wordpress-plugin/10458750?ref=valiano" target="_blank">Buy Now</a></li>
			 					</ul>
							</li>
							<li class='dropdown'>
								<a href="http://unitecms.net/premium-extensions/unite-gallery-main/default-theme" class="dropdown-toggle" target="_blank" >Joomla!</a>
 								<ul class="dropdown-menu">
	 								<li><a href="http://unitecms.net/premium-extensions/unite-gallery-main/default-theme" target="_blank">Preview Demo</a></li>
									<li><a href="http://unitecms.net/cart?productid=29" target="_blank">Buy Now</a></li>
			 					</ul>
							</li>							
							<li class='dropdown'>
								<a href="http://ps.unitegallery.net/content/6-ug-default-theme" target="_blank" class="dropdown-toggle">PrestaShop</a>
 								<ul class="dropdown-menu"> 				
	 								<li><a href="http://ps.unitegallery.net/content/6-ug-default-theme" target="_blank">Preview Demo</a></li>
									<li><a href="http://codecanyon.net/item/unite-gallery-prestashop-module/9871980?ref=valiano" target="_blank">Buy Now</a></li>
			 					</ul>
							</li>						
							<li class='dropdown'>
								<a href="http://oc.unitegallery.net/index.php?route=information/information&information_id=7" target="_blank" class="dropdown-toggle" >OpenCart</a>
 								<ul class="dropdown-menu">
	 								<li><a href="http://oc.unitegallery.net/index.php?route=information/information&information_id=7" target="_blank">Preview Demo</a></li>			
	 								<li><a href="http://codecanyon.net/item/unite-gallery-opencart-module/9904479?ref=valiano" target="_blank">Buy Now</a></li>			
			 					</ul>									
							</li>
							<li class='dropdown'>
								<a href="http://oc.unitegallery.net/index.php?route=information/information&information_id=7" target="_blank" class="dropdown-toggle" >Drupal</a>
 								<ul class="dropdown-menu">
	 								<li><a href="http://drupal.unitegallery.net/" target="_blank">Preview Demo</a></li>			
	 								<li><a href="http://codecanyon.net/item/unite-gallery-drupal-module/11560330?ref=valiano" target="_blank">Buy Now</a></li>			
			 					</ul>									
							</li>
							<li class='dropdown'>
								<a href="http://oc.unitegallery.net/index.php?route=information/information&information_id=7" target="_blank" class="dropdown-toggle" >PHP CMS</a>
 								<ul class="dropdown-menu">
	 								<li><a href="http://cms.unitegallery.net" target="_blank">Preview Demo</a></li>			
	 								<li><a href="http://codecanyon.net/item/unite-gallery-with-php-admin/12506226?ref=valiano" target="_blank">Buy Now</a></li>			
			 					</ul>
							</li>
							
						</ul>
						</nav>
					</div>
					
					<nav>
					
												<ul class="nav nav-pills nav-top">
							<li >
								<a href="index.php?page=documentation" >DOCUMENTATION</a>
							</li>
							<li>
								<a href="https://github.com/vvvmax/unitegallery/" target="_blank" >GITHUB</a>
							</li>														
							<li>
								<a id="link_download" href="https://github.com/vvvmax/unitegallery/archive/master.zip" >DOWNLOAD</a>
							</li>							
						</ul>
					
					</nav>
					<button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">
						<i class="icon icon-bars"></i>
					</button>
				</div>
				

				<div class="navbar-collapse nav-main-collapse collapse">
					
					<!-- class="container" -->
					
					<div >
						<nav class="nav-main mega-menu">
							
									
			<ul class="nav nav-pills nav-main" id="mainMenu">
							<li class='dropdown active'>
											<a class="dropdown-toggle" href="index.php?page=tiles-columns">
							Tiles - Columns							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=tiles-columns">Tiles - Columns - Default</a></li>			
							<li><a href="index.php?page=tiles-columns-links">Tiles - Columns - With Links</a></li>			
							<li><a href="index.php?page=tiles-columns-video">Tiles - Columns - Video Items</a></li>			
							<li><a href="index.php?page=tiles-columns-variuos">Tiles - Columns - Various Examples</a></li>			
							<li><a href="index.php?page=tiles-columns-options">Tiles - Columns - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=tiles-justified">
							Tiles - Justified							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=tiles-justified">Tiles - Justified - Default</a></li>			
							<li><a href="index.php?page=tiles-justified-links">Tiles - Justified - With Links</a></li>			
							<li><a href="index.php?page=tiles-justified-various">Tiles - Justified - Various Examples</a></li>			
							<li><a href="index.php?page=tiles-justified-options">Tiles - Justified - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=tiles-nested">
							Tiles - Nested							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=tiles-nested">Tiles - Nested - Default</a></li>			
							<li><a href="index.php?page=tiles-nested-size">Tiles - Nested - Another Size</a></li>			
							<li><a href="index.php?page=tiles-nested-options">Tiles - Nested - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=tilesgrid">
							Tiles Grid							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=tilesgrid">Tiles Grid - Default</a></li>			
							<li><a href="index.php?page=tilesgrid-arrows">Tiles Grid - Navigation Arrows</a></li>			
							<li><a href="index.php?page=tilesgrid-video">Tiles Grid - Video Items</a></li>			
							<li><a href="index.php?page=tilesgrid-variuos">Tiles Grid - Various Examples</a></li>			
							<li><a href="index.php?page=tilesgrid-options">Tiles Grid - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=carousel">
							Carousel							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=carousel">Carousel - Default</a></li>			
							<li><a href="index.php?page=carousel-video">Carousel - Video Items</a></li>			
							<li><a href="index.php?page=carousel-another-video">Carousel - Another Video Items</a></li>			
							<li><a href="index.php?page=carousel-various">Carousel - Various Examples</a></li>			
							<li><a href="index.php?page=carousel-options">Carousel - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=default">
							Default Theme							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=default">Default Theme - Default</a></li>			
							<li><a href="index.php?page=default-notext">Default Theme - No Textpanel</a></li>			
							<li><a href="index.php?page=default-variuos">Default Theme - Variuos Examples</a></li>			
							<li><a href="index.php?page=default-options">Default Theme - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=compact-bottom">
							Compact Theme							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=compact-bottom">Compact Theme - Bottom Panel</a></li>			
							<li><a href="index.php?page=compact-top">Compact Theme - Top Panel</a></li>			
							<li><a href="index.php?page=compact-right">Compact Theme - Right Panel</a></li>			
							<li><a href="index.php?page=compact-left">Compact Theme - Left Panel</a></li>			
							<li><a href="index.php?page=compact-variuos">Compact Theme - Variuos Examples</a></li>			
							<li><a href="index.php?page=compact-options">Compact Theme - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=grid-right">
							Grid Theme							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=grid-right">Grid Theme - Right Panel</a></li>			
							<li><a href="index.php?page=grid-left">Grid Theme - Left Panel</a></li>			
							<li><a href="index.php?page=grid-bottom">Grid Theme - Bottom Panel</a></li>			
							<li><a href="index.php?page=grid-top">Grid Theme - Top Panel</a></li>			
							<li><a href="index.php?page=grid-horizontal">Grid Theme - Horizontal Navigation</a></li>			
							<li><a href="index.php?page=grid-various">Grid Theme - Variuos Examples</a></li>			
							<li><a href="index.php?page=grid-options">Grid Theme - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=slider-example">
							Slider							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=slider-example">Slider Theme - Example</a></li>			
							<li><a href="index.php?page=slider-video">Slider Theme - Video Items</a></li>			
							<li><a href="index.php?page=slider-options">Slider Theme - Including And Options</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=video-icon">
							Video Gallery							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=video-icon">Video Gallery - With Icon</a></li>			
							<li><a href="index.php?page=video-both">Video Gallery - Title and Description</a></li>			
							<li><a href="index.php?page=video-title">Video Gallery - Title Only</a></li>			
							<li><a href="index.php?page=video-theme-options">Video Gallery - Theme Including And Options</a></li>			
							<li><a href="index.php?page=video-items-syntax">Video Gallery - Items Syntax</a></li>			
			 </ul>				</li>
								<li class='dropdown'>
											<a class="dropdown-toggle" href="index.php?page=examples-skin">
							More							<i class="icon icon-angle-down"></i>
						</a>					
					 <ul class="dropdown-menu"> 				<li><a href="index.php?page=examples-skin">Custom Skin Change</a></li>			
							<li><a href="index.php?page=examples-api">Using The API</a></li>			
			 </ul>				</li>
										
						</nav>
					</div>
					
	
				</div>
			</header>

			<div role="main" class="main">
			

				<div class="container">
				
				
	<h3>Tiles - Columns</h3>

		<div id="gallery1" style="margin:0px auto;display:none;">
		
								<a href="http://unitegallery.net">
						<img alt="Lemon Slice"
						     src="newimages/image01-300x200.jpg"
						     data-image="newimages/image01.jpg"
						     data-description="This is a Lemon Slice"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Peppers"
						     src="newimages/image04-300x300.jpg"
						     data-image="newimages/image04.jpg"
						     data-description="Those are peppers"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Keys"
						     src="newimages/image03-247x300.jpg"
						     data-image="newimages/image03.jpg"
						     data-description="Those are keys"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Friuts in cup"
						     src="newimages/image08-274x300.jpg"
						     data-image="newimages/image08.jpg"
						     data-description="Those are friuts in a cup"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Yellow Flowers"
						     src="newimages/image06-300x225.jpg"
						     data-image="newimages/image06.jpg"
						     data-description="Those are yellow flowers"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Butterfly"
						     src="newimages/image05-300x273.jpg"
						     data-image="newimages/image05.jpg"
						     data-description="This is butterfly"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Boat"
						     src="newimages/image02-300x241.jpg"
						     data-image="newimages/image02.jpg"
						     data-description="This is a boat"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Woman"
						     src="newimages/image13-199x300.jpg"
						     data-image="newimages/image13.jpg"
						     data-description="This is a woman"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Cup Of Coffee"
						     src="newimages/image34-300x239.jpg"
						     data-image="newimages/image34.jpg"
						     data-description="This is cup of coffee"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Iphone Back"
						     src="newimages/image46-300x199.jpg"
						     data-image="newimages/image46.jpg"
						     data-description="This is iphone back"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Sushi"
						     src="newimages/image16-300x225.jpg"
						     data-image="newimages/image16.jpg"
						     data-description="This is sushi"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Cat in Basket"
						     src="newimages/image10-300x199.jpg"
						     data-image="newimages/image10.jpg"
						     data-description="This is a cat in basket"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Vechtables"
						     src="newimages/image11-300x200.jpg"
						     data-image="newimages/image11.jpg"
						     data-description="Those are vechtables"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Purple Flower"
						     src="newimages/image12-300x228.jpg"
						     data-image="newimages/image12.jpg"
						     data-description="Thsi is purple flower"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Old Keys"
						     src="newimages/image58-300x239.jpg"
						     data-image="newimages/image58.jpg"
						     data-description="Those are old keys"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Sweet Slices"
						     src="newimages/image09-300x176.jpg"
						     data-image="newimages/image09.jpg"
						     data-description="Those are sweet slices"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Woman under Umbrella"
						     src="newimages/image17-300x300.jpg"
						     data-image="newimages/image17.jpg"
						     data-description="This is a woman under umbrella"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Brown Butterfly"
						     src="newimages/image18-300x199.jpg"
						     data-image="newimages/image18.jpg"
						     data-description="Thsi is brown butterfly"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Whtie Cup"
						     src="newimages/image51-199x300.jpg"
						     data-image="newimages/image51.jpg"
						     data-description="This is white cup"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Blue Butterfly"
						     src="newimages/image19-300x200.jpg"
						     data-image="newimages/image19.jpg"
						     data-description="This is blue butterfly"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Bread"
						     src="newimages/image15-300x241.jpg"
						     data-image="newimages/image15.jpg"
						     data-description="This is bread"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Iphone"
						     src="newimages/image33-300x168.jpg"
						     data-image="newimages/image33.jpg"
						     data-description="This is Iphone"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Berries"
						     src="newimages/image77-300x187.jpg"
						     data-image="newimages/image77.jpg"
						     data-description="Those are berries"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Colorful Umbrellas"
						     src="newimages/image65-300x199.jpg"
						     data-image="newimages/image65.jpg"
						     data-description="Those are colorful umbrellas"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Shakes Love"
						     src="newimages/new04-200x300.jpg"
						     data-image="newimages/new04.jpg"
						     data-description="Those are shakes love"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Woman Reading"
						     src="newimages/image48-300x214.jpg"
						     data-image="newimages/image48.jpg"
						     data-description="This is woman reading"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Running Siluette"
						     src="newimages/image38-300x225.jpg"
						     data-image="newimages/image38.jpg"
						     data-description="This is running siluette"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Some Fruits"
						     src="newimages/image21-300x199.jpg"
						     data-image="newimages/image21.jpg"
						     data-description="Those are some fruits"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Branches"
						     src="newimages/image52-300x199.jpg"
						     data-image="newimages/image52.jpg"
						     data-description="Those are brunches"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Phone Case"
						     src="newimages/image40-300x200.jpg"
						     data-image="newimages/image40.jpg"
						     data-description="This is phone case"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Spec Butterfly"
						     src="newimages/image25-300x200.jpg"
						     data-image="newimages/image25.jpg"
						     data-description="This is speck butterfly"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Drum Band"
						     src="newimages/image57-300x232.jpg"
						     data-image="newimages/image57.jpg"
						     data-description="This is drum band"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Sports Car"
						     src="newimages/car07-300x225.jpg"
						     data-image="newimages/car07.jpg"
						     data-description="This is sports car"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Bools Stack"
						     src="newimages/image26-300x195.jpg"
						     data-image="newimages/image26.jpg"
						     data-description="This is a books stack"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Choko Pie"
						     src="newimages/image14-300x271.jpg"
						     data-image="newimages/image14.jpg"
						     data-description="This is a choko pie"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Flying Umbrellas"
						     src="newimages/image69-300x225.jpg"
						     data-image="newimages/image69.jpg"
						     data-description="Those are flying umbrellas"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Arc to Sea"
						     src="newimages/image49-300x214.jpg"
						     data-image="newimages/image49.jpg"
						     data-description="This is arc to see"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="GPS Phone"
						     src="newimages/image59-300x199.jpg"
						     data-image="newimages/image59.jpg"
						     data-description="This is a GPS phone"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Food on tray"
						     src="newimages/image74-300x187.jpg"
						     data-image="newimages/image74.jpg"
						     data-description="This is food on a tray"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Several Fruits"
						     src="newimages/image61-300x201.jpg"
						     data-image="newimages/image61.jpg"
						     data-description="Those are several fruits"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Apples"
						     src="newimages/image76-300x187.jpg"
						     data-image="newimages/image76.jpg"
						     data-description="Those are apples"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Times Square"
						     src="newimages/image45-300x214.jpg"
						     data-image="newimages/image45.jpg"
						     data-description="This is times square"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Green Fish"
						     src="newimages/image41-300x199.jpg"
						     data-image="newimages/image41.jpg"
						     data-description="This is green fish"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Gondola"
						     src="newimages/image42-300x203.jpg"
						     data-image="newimages/image42.jpg"
						     data-description="This is a gondola"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Shrimps"
						     src="newimages/image43-300x199.jpg"
						     data-image="newimages/image43.jpg"
						     data-description="This is shrimps"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Yellow Flower"
						     src="newimages/image47-300x212.jpg"
						     data-image="newimages/image47.jpg"
						     data-description="This is yellow flower"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Coffee Shop Tables"
						     src="newimages/image50-300x199.jpg"
						     data-image="newimages/image50.jpg"
						     data-description="Those are coffee shop tables"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Big City"
						     src="newimages/image53-300x200.jpg"
						     data-image="newimages/image53.jpg"
						     data-description="This is a big city"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Ref Leaf"
						     src="newimages/new08-300x206.jpg"
						     data-image="newimages/new08.jpg"
						     data-description="This is a red leaf"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Bean"
						     src="newimages/image54-300x199.jpg"
						     data-image="newimages/image54.jpg"
						     data-description="This is a bean"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Cranberries"
						     src="newimages/image35-300x185.jpg"
						     data-image="newimages/image35.jpg"
						     data-description="Those are cranberries"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Market"
						     src="newimages/image60-300x200.jpg"
						     data-image="newimages/image60.jpg"
						     data-description="This is a market"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Nemo Fish"
						     src="newimages/image66-300x168.jpg"
						     data-image="newimages/image66.jpg"
						     data-description="This is a nemo fish"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Violet Flower"
						     src="newimages/new05-239x300.jpg"
						     data-image="newimages/new05.jpg"
						     data-description="This is a violet flower"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Coffee Beans"
						     src="newimages/image70-300x199.jpg"
						     data-image="newimages/image70.jpg"
						     data-description="Those are coffee beans"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Fruits With Yogurt"
						     src="newimages/image79-300x168.jpg"
						     data-image="newimages/image79.jpg"
						     data-description="Those are fruits with yogurt"
						     style="display:none">
						</a>

						<a href="http://unitegallery.net">
						<img alt="Make Up"
						     src="newimages/image63-300x199.jpg"
						     data-image="newimages/image63.jpg"
						     data-description="This is make up"
						     style="display:none">
						</a>		
		
		</div>
		
		<script type="text/javascript">
	
			jQuery(document).ready(function(){
	
				jQuery("#gallery1").unitegallery();
	
			});
			
		</script>
		
		<br><br><br>
		Options to put this gallery:
		<code>
			jQuery("#gallery").unitegallery();
		</code>	
		

				</div>

			</div>

			<footer id="footer">
		
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-1">
								<a href="index.php" class="logo">
									<img alt="Unite Gallery Logo"  src="img/logo_bottom.png">
								</a>
							</div>
							<div class="footer-copy-row col-md-7">
								<p>
									&copy; Copyright 2014. All Rights Reserved.
									&nbsp;&nbsp;&nbsp;&nbsp; Photos by <a href="http://evelivesey.deviantart.com/" target="_blank">Eve Livesey</a>
								</p>
							</div>
							<div class="footer-menu-row col-md-4">
								<nav id="sub-menu">
									<ul>
										<li><a href="index.php?page=documentation">Documentation</a></li>
										<li><a href="index.php?page=contact">Contact Us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>
		
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52539524-1', 'auto');
  ga('send', 'pageview');

</script>

	</body>
</html>
